
import React from 'react';
import RouterController from './routeController';
function App() {
  return (
    <div className="App">
        <RouterController />;
     
    </div>
  );
}

export default App;
